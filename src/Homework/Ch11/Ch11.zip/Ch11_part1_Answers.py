##Chapter 11
##Algorithm portion

##Problem 2

#output: sapling
#output: tree
#output: I'm a plant.
#output: I'm a tree.

#Problem 3

class Cola(Beverage):
    def __init__(self, bev_name = 'cola'):
        Beverage.__init__(self, bev_name)
